﻿namespace Cyotek.Windows.Forms
{
  internal enum ImageBoxPanDirection
  {
    None,

    Up,

    Down,

    Left,

    Right
  }
}
