﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cyotek.Windows.Forms
{
  internal enum ImageBoxPanStyle
  {
    None,
    Standard,
    Free
  }
}
